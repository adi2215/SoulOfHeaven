using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu]
public class MainData : ScriptableObject
{
    public bool moveIdle;
}
