public static class WorldTimeConstant
{
    public const int MinutesInDay = 1440;
}
